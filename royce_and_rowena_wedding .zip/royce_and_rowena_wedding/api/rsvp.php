<?php
require_once '../includes/db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if RSVP is enabled
    if (get_setting('rsvp_enabled', '1') == '0') {
        echo json_encode([
            'success' => false, 
            'message' => get_setting('rsvp_disabled_message', 'RSVP submissions are currently closed by the couple.')
        ]);
        exit;
    }

    $full_name = trim($_POST['full_name'] ?? '');
    $attendance = $_POST['attendance'] ?? '';
    $contact_number = trim($_POST['contact_number'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($full_name) || empty($attendance) || empty($contact_number)) {
        echo json_encode(['success' => false, 'message' => 'Full Name, Attendance, and Contact Number are required.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO rsvps (full_name, attendance, contact_number, message) VALUES (?, ?, ?, ?)");
        $stmt->execute([$full_name, $attendance, $contact_number, $message]);
        $inserted_id = $pdo->lastInsertId();

        $fetch_stmt = $pdo->prepare("SELECT full_name, attendance, message, submitted_at FROM rsvps WHERE id = ?");
        $fetch_stmt->execute([$inserted_id]);
        $rsvp_data = $fetch_stmt->fetch();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Thank you! Your RSVP has been received.',
            'data' => $rsvp_data
        ]);
    } catch (\PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'A database error occurred. Please try again.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
