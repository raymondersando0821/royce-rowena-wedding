---
name: Wedding Invitation Design System
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#43474e'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#000d22'
  on-primary: '#ffffff'
  primary-container: '#002349'
  on-primary-container: '#718bb7'
  inverse-primary: '#adc8f6'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#0c0d0b'
  on-tertiary: '#ffffff'
  tertiary-container: '#222320'
  on-tertiary-container: '#8b8a86'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#adc8f6'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2c476f'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474744'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 64px
    fontWeight: '400'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 40px
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: 0em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '400'
    lineHeight: '1.3'
    letterSpacing: 0em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.2em
spacing:
  unit: 8px
  container-max: 1140px
  gutter: 24px
  section-padding: 120px
  stack-sm: 16px
  stack-md: 32px
  stack-lg: 64px
---

## Brand & Style
The design system is anchored in the concept of "Timeless Modernity." It evokes the gravitas of a traditional black-tie wedding while utilizing contemporary digital layouts to ensure a seamless guest experience. The aesthetic is rooted in **Minimalism** with a focus on high-quality editorial typography and generous negative space. 

Visual storytelling is prioritized through a refined, airy layout that allows photography and type to breathe. The emotional response is one of exclusivity, romance, and meticulous attention to detail. All interface elements should feel like digital extensions of high-end stationery—tactile, intentional, and precious.

## Colors
The palette is a classic triumvirate of Navy, Gold, and White, curated to maintain a high-contrast yet harmonious balance.

- **Primary (Navy):** Used for primary headings, navigation backgrounds, and high-emphasis components. It represents stability and formal elegance.
- **Secondary (Gold):** Used sparingly for accents, iconography, and decorative borders. It provides the "jewelry" of the interface.
- **Tertiary (Cream/Off-White):** Used as the primary canvas color to reduce the harshness of pure white, creating a more romantic and soft atmosphere.
- **Neutral:** A deep charcoal used for body text to ensure maximum legibility without the starkness of pure black.

## Typography
This design system utilizes a high-contrast typographic pairing to reinforce the luxury narrative. 

**Noto Serif** is the voice of the event, used for names, section titles, and quotes. It should be typeset with ample line height to maintain a sense of lightness. 

**Manrope** provides the functional clarity required for logistics (itinerary, maps, RSVP forms). For a more sophisticated touch, use the `label-caps` style for small headers and navigation items to introduce a rhythmic, architectural feel to the layout.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop to emulate the structured boundaries of a physical invitation card, while transitioning to a fluid model for mobile.

- **Airy Rhythm:** Vertical spacing is intentionally exaggerated. Sections should be separated by `section-padding` to prevent the UI from feeling cluttered.
- **Negative Space:** Maintain at least 80px of horizontal margin on desktop layouts.
- **Alignment:** Central alignment is preferred for ceremonial content (Home, Our Story), while asymmetrical or left-aligned grids should be used for information-dense sections (Schedule, Registry) to maintain a modern edge.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** rather than heavy shadows. The design system rejects traditional "floating" elements in favor of a flat, layered stationery aesthetic.

- **Surfaces:** Use subtle shifts between the Tertiary (Cream) and pure White to define content blocks.
- **Soft Outlines:** Instead of shadows, use 1px solid borders in `accent_gold_light` or a very faint Navy at 10% opacity to define cards and input fields.
- **Micro-shadows:** Only used for interactive states (e.g., a button press), utilizing a very soft, gold-tinted ambient blur to suggest a physical lift.

## Shapes
The shape language is strictly **Sharp (0)**. 

To maintain the sophisticated, modern-classic look of high-end printing, all buttons, images, and input fields should utilize 90-degree corners. This evokes the crisp edges of premium cardstock. Decorative elements, such as thin gold dividers or frame-style borders, should also follow linear, geometric paths.

## Components
Consistent execution of components ensures the design system remains cohesive across the guest journey.

- **Buttons:** Primary buttons are solid Navy with Gold text or White text, always rectangular. Secondary buttons are "Ghost" style with a 1px Gold border and `label-caps` typography.
- **Input Fields:** Use minimal bottom-border only styling for a "fill-in-the-blank" stationery feel, or a full 1px border. Backgrounds should be slightly lighter than the page background.
- **Cards:** Cards for the wedding party or registry items should have no background and no shadow, defined instead by a thin 1px Gold frame or generous white space.
- **RSVP Toggle:** Use a custom-styled radio button that appears as a classic check-box or an elegant circular mark, avoiding standard OS-default styling.
- **Dividers:** Use "The Signature Line"—a 1px Gold horizontal line, often centered, used to separate major story beats.
- **Interactive Flourish:** Subtle fade-in animations as the user scrolls to mimic the "reveal" of opening an envelope.