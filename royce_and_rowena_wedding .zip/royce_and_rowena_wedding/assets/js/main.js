document.addEventListener("DOMContentLoaded", function () {
    // --- RSVP Logic ---
    const rsvpForm = document.getElementById("rsvp-form");
    const rsvpModal = document.getElementById("rsvp-modal");
    const rsvpModalContent = document.getElementById("rsvp-modal-content");
    const closeModalBtn = document.getElementById("close-rsvp-modal");
    let rsvpSubmitted = false;

    // Helper to escape HTML tags for secure content rendering
    function escapeHtml(str) {
        return String(str || '').replace(/[&<>"']/g, function (s) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[s];
        });
    }

    if (rsvpForm) {
        rsvpForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const formData = new FormData(rsvpForm);
            const attendance = formData.get('attendance');
            
            fetch((window.BASE_URL || '') + "/api/rsvp.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const modalTitle = document.getElementById("rsvp-modal-title");
                    const modalText = document.getElementById("rsvp-modal-text");

                    if (attendance === "Yes") {
                        modalTitle.innerText = "Thank You!";
                        modalText.innerText = "We are so excited to celebrate with you. See you there!";
                    } else {
                        modalTitle.innerText = "Thank You";
                        modalText.innerText = "We're sorry you can't make it, but we appreciate you letting us know!";
                    }

                    rsvpModal.classList.remove("hidden");
                    requestAnimationFrame(() => {
                        rsvpModalContent.classList.remove("scale-95", "opacity-0");
                        rsvpModalContent.classList.add("scale-100", "opacity-100");
                    });
                    
                    // Dynamically prepend new message to the wishes column
                    if (data.data && data.data.message && data.data.message.trim() !== '') {
                        const wishesList = document.getElementById("wishes-list");
                        const noWishesPlaceholder = document.getElementById("no-wishes-placeholder");
                        
                        if (noWishesPlaceholder) {
                            noWishesPlaceholder.classList.add("hidden");
                        }

                        if (wishesList) {
                            const wish = data.data;
                            const firstLetter = wish.full_name.trim().charAt(0).toUpperCase();

                            const card = document.createElement("div");
                            card.className = "wish-card bg-white/50 dark:bg-slate-950/50 backdrop-blur-sm border border-amber-200/10 p-5 rounded-2xl flex gap-4 transition-all duration-300 hover:border-amber-200/40 hover:bg-white/70 animate-wish-entry";

                            card.innerHTML = `
                                <div class="flex-shrink-0">
                                    <div class="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-secondary font-bold text-sm uppercase ring-2 ring-amber-200/20">
                                        ${escapeHtml(firstLetter)}
                                    </div>
                                </div>
                                <div class="flex-grow">
                                    <div class="mb-1">
                                        <span class="font-bold text-primary font-serif leading-tight">
                                            ${escapeHtml(wish.full_name)}
                                        </span>
                                    </div>
                                    <p class="font-body-md text-on-surface-variant italic leading-relaxed text-slate-600 dark:text-slate-300">
                                        "${escapeHtml(wish.message)}"
                                    </p>
                                </div>
                            `;

                            wishesList.insertBefore(card, wishesList.firstChild);
                            wishesList.scrollTop = 0; // scroll to top to see newly added wish
                        }
                    }

                    rsvpSubmitted = true;
                    rsvpForm.reset();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("Sorry, there was an issue saving your RSVP.");
            });
        });
    }

    if (closeModalBtn) {
        closeModalBtn.addEventListener("click", function() {
            rsvpModalContent.classList.remove("scale-100", "opacity-100");
            rsvpModalContent.classList.add("scale-95", "opacity-0");
            setTimeout(() => {
                rsvpModal.classList.add("hidden");
                if (rsvpSubmitted) {
                    const otherDetails = document.getElementById('other-details');
                    if (otherDetails) {
                        otherDetails.classList.remove('hidden');
                        // Animate in
                        otherDetails.style.opacity = '0';
                        otherDetails.style.transform = 'translateY(40px)';
                        otherDetails.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
                        requestAnimationFrame(() => {
                            requestAnimationFrame(() => {
                                otherDetails.style.opacity = '1';
                                otherDetails.style.transform = 'translateY(0)';
                            });
                        });
                        setTimeout(() => {
                            otherDetails.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }, 100);
                    }
                }
            }, 300);
        });
    }

    // --- Gallery Lightbox ---
    const lightbox = document.getElementById("gallery-lightbox");
    const lightboxImg = document.getElementById("lightbox-img");
    const lightboxContent = document.getElementById("lightbox-content");
    const lightboxCaption = document.getElementById("lightbox-caption");
    const closeLightboxBtn = document.getElementById("close-lightbox");
    const galleryTriggers = document.querySelectorAll(".gallery-trigger");

    if (lightbox && galleryTriggers.length > 0) {
        let isLightboxOpen = false;

        const closeLightbox = () => {
            if (!isLightboxOpen) return;
            isLightboxOpen = false;
            lightboxContent.classList.remove("scale-100", "opacity-100");
            lightboxContent.classList.add("scale-95", "opacity-0");
            setTimeout(() => lightbox.classList.add("hidden"), 300);
            window.removeEventListener("scroll", handleScrollClose);
        };

        const handleScrollClose = () => { if (isLightboxOpen) closeLightbox(); };

        galleryTriggers.forEach(img => {
            img.addEventListener("click", function() {
                lightboxImg.setAttribute("src", this.getAttribute("src"));
                lightboxCaption.innerText = this.getAttribute("data-alt") || "";
                lightbox.classList.remove("hidden");
                isLightboxOpen = true;
                requestAnimationFrame(() => {
                    lightboxContent.classList.remove("scale-95", "opacity-0");
                    lightboxContent.classList.add("scale-100", "opacity-100");
                });
                window.addEventListener("scroll", handleScrollClose, { passive: true });
            });
        });

        if (closeLightboxBtn) closeLightboxBtn.addEventListener("click", closeLightbox);
        lightbox.addEventListener("click", (e) => { if (e.target === lightbox) closeLightbox(); });
        document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeLightbox(); });
    }

    // --- Background Slideshow (Hero) ---
    const heroSlides = document.querySelectorAll('.slideshow-item');
    if (heroSlides.length > 1) {
        let currentHeroSlide = 0;
        setInterval(() => {
            heroSlides[currentHeroSlide].classList.replace('opacity-100', 'opacity-0');
            currentHeroSlide = (currentHeroSlide + 1) % heroSlides.length;
            heroSlides[currentHeroSlide].classList.replace('opacity-0', 'opacity-100');
        }, 4000);
    }

    // --- Our Story Slideshow ---
    const storySlides = document.querySelectorAll('.story-slideshow-item');
    if (storySlides.length > 1) {
        let currentStorySlide = 0;
        setInterval(() => {
            storySlides[currentStorySlide].classList.replace('opacity-100', 'opacity-0');
            currentStorySlide = (currentStorySlide + 1) % storySlides.length;
            storySlides[currentStorySlide].classList.replace('opacity-0', 'opacity-100');
        }, 4000);
    }



    // --- Countdown ---
    const countdown = document.getElementById('countdown');
    if (countdown) {
        function updateCountdown() {
            const dateStr = countdown.dataset.date;
            const target = new Date(dateStr).getTime();
            const now = new Date().getTime();
            const dist = target - now;

            if (isNaN(target) || dist <= 0) {
                document.getElementById('days').innerText = '00';
                document.getElementById('hours').innerText = '00';
                document.getElementById('minutes').innerText = '00';
                document.getElementById('seconds').innerText = '00';
                return;
            }

            document.getElementById('days').innerText = Math.floor(dist / 86400000).toString().padStart(2, '0');
            document.getElementById('hours').innerText = Math.floor((dist % 86400000) / 3600000).toString().padStart(2, '0');
            document.getElementById('minutes').innerText = Math.floor((dist % 3600000) / 60000).toString().padStart(2, '0');
            document.getElementById('seconds').innerText = Math.floor((dist % 60000) / 1000).toString().padStart(2, '0');
        }

        updateCountdown();
        setInterval(updateCountdown, 1000);
    }

    // --- Gallery Toggle ---
    const galleryBtn = document.getElementById('toggle-gallery');
    const extraGallery = document.getElementById('extra-gallery');
    if (galleryBtn && extraGallery) {
        galleryBtn.addEventListener('click', () => {
            extraGallery.classList.toggle('hidden');
            galleryBtn.innerText = extraGallery.classList.contains('hidden') ? 'See more pictures' : 'See less pictures';
        });
    }

    // --- FAQ Accordion ---
    const faqToggles = document.querySelectorAll('.faq-toggle');
    faqToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const item = this.closest('.faq-item');
            const content = item.querySelector('.faq-content');
            const icon = item.querySelector('.faq-icon');
            const isOpen = !content.classList.contains('max-h-0');

            // Close all other FAQs
            document.querySelectorAll('.faq-item').forEach(otherItem => {
                if (otherItem !== item) {
                    const otherContent = otherItem.querySelector('.faq-content');
                    const otherIcon = otherItem.querySelector('.faq-icon');
                    otherContent.style.maxHeight = '0px';
                    otherContent.classList.add('max-h-0');
                    otherIcon.classList.remove('rotate-45');
                }
            });

            // Toggle current FAQ
            if (isOpen) {
                content.style.maxHeight = '0px';
                content.classList.add('max-h-0');
                icon.classList.remove('rotate-45');
            } else {
                content.classList.remove('max-h-0');
                content.style.maxHeight = content.scrollHeight + 'px';
                icon.classList.add('rotate-45');
            }
        });
    });

    // --- Mobile Menu Toggle ---
    const mobileMenuToggle = document.getElementById("mobile-menu-toggle");
    const mobileMenuClose = document.getElementById("mobile-menu-close");
    const mobileDrawer = document.getElementById("mobile-drawer");
    const mobileNavLinks = document.querySelectorAll(".mobile-nav-link");

    if (mobileMenuToggle && mobileDrawer) {
        mobileMenuToggle.addEventListener("click", () => {
            mobileDrawer.classList.remove("translate-x-full");
            mobileDrawer.classList.add("translate-x-0");
            document.body.classList.add("overflow-hidden");
        });
    }

    const closeMobileDrawer = () => {
        if (mobileDrawer) {
            mobileDrawer.classList.remove("translate-x-0");
            mobileDrawer.classList.add("translate-x-full");
            document.body.classList.remove("overflow-hidden");
        }
    };

    if (mobileMenuClose) {
        mobileMenuClose.addEventListener("click", closeMobileDrawer);
    }

    mobileNavLinks.forEach(link => {
        link.addEventListener("click", closeMobileDrawer);
    });

    // --- Wish Card Staggered Entrance Animation (IntersectionObserver) ---
    const wishesList = document.getElementById("wishes-list");

    if (wishesList) {
        const wishCards = wishesList.querySelectorAll(".wish-card:not(.animate-wish-entry)");

        // Stagger delay per card
        wishCards.forEach((card, index) => {
            card.style.transitionDelay = `${index * 90}ms`;
        });

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const cards = entry.target.querySelectorAll(".wish-card:not(.animate-wish-entry)");
                    cards.forEach((card, index) => {
                        setTimeout(() => {
                            card.classList.add("is-visible");
                        }, index * 90);
                    });
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.05 });

        observer.observe(wishesList);

        // --- Seamless Infinite Auto-Scroll ---
        // Only activate if there are enough cards to actually scroll
        if (wishCards.length > 2) {
            // 1. Clone all original cards and append them after the originals.
            //    This creates a "double" list — when we reach the end of the
            //    originals we silently jump back to the start; the clones fill
            //    the gap so the viewer never sees a reset.
            const originalCards = Array.from(wishCards);
            originalCards.forEach(card => {
                const clone = card.cloneNode(true);
                // Cloned cards are already visible — skip the entrance anim
                clone.classList.add("is-visible");
                clone.classList.remove("animate-wish-entry");
                clone.style.transitionDelay = "0ms";
                wishesList.appendChild(clone);
            });

            let scrollPaused = false;
            let rafId = null;
            const SPEED = 0.6; // px per frame — tweak for faster/slower

            const tick = () => {
                if (!scrollPaused) {
                    wishesList.scrollTop += SPEED;

                    // When we've scrolled past the original set of cards
                    // (i.e. scrollTop ≥ height of one "set"), silently jump
                    // back to the top. The clones absorb the visual continuity.
                    const halfHeight = wishesList.scrollHeight / 2;
                    if (wishesList.scrollTop >= halfHeight) {
                        // Instant, imperceptible reset to the equivalent position
                        // in the first half (no smooth scroll — that caused the drag)
                        wishesList.scrollTop -= halfHeight;
                    }
                }
                rafId = requestAnimationFrame(tick);
            };

            // Pause on hover/touch so users can read at their leisure
            wishesList.addEventListener("mouseenter", () => { scrollPaused = true; });
            wishesList.addEventListener("mouseleave", () => {
                setTimeout(() => { scrollPaused = false; }, 600);
            });
            wishesList.addEventListener("touchstart", () => { scrollPaused = true; }, { passive: true });
            wishesList.addEventListener("touchend", () => {
                setTimeout(() => { scrollPaused = false; }, 1200);
            });

            // Start after entrance animations finish
            setTimeout(() => { rafId = requestAnimationFrame(tick); }, 2200);
        }
    }

    // --- Background Music Autoplay & Controls ---
    const bgMusic = document.getElementById("bg-music");
    const bgMusicToggle = document.getElementById("bg-music-toggle");
    const musicIcon = document.getElementById("music-icon");
    const musicPulse = document.getElementById("music-pulse");

    if (bgMusic && bgMusicToggle) {
        // Retrieve last stored user preference (default to play/unmuted if not set)
        let isMuted = localStorage.getItem("bg_music_muted") === "true";

        // Function to update visual controls based on playing state
        function updateUI(isPlaying) {
            if (!bgMusic.muted) {
                musicIcon.innerText = "volume_up";
                if (isPlaying && !bgMusic.paused) {
                    musicPulse.classList.remove("hidden");
                } else {
                    musicPulse.classList.add("hidden");
                }
            } else {
                musicIcon.innerText = "volume_off";
                musicPulse.classList.add("hidden");
            }
        }

        // Toggle sound playback
        function togglePlay() {
            if (bgMusic.paused) {
                bgMusic.muted = false;
                bgMusic.play()
                    .then(() => {
                        localStorage.setItem("bg_music_muted", "false");
                        updateUI(true);
                    })
                    .catch(err => console.log("Playback failed:", err));
            } else {
                if (bgMusic.muted) {
                    bgMusic.muted = false;
                    localStorage.setItem("bg_music_muted", "false");
                    updateUI(true);
                } else {
                    bgMusic.muted = true;
                    localStorage.setItem("bg_music_muted", "true");
                    updateUI(false);
                }
            }
        }

        bgMusicToggle.addEventListener("click", function (e) {
            e.stopPropagation();
            togglePlay();
        });

        // Initialize state
        bgMusic.muted = isMuted;
        updateUI(!isMuted);

        // --- Welcome Overlay Handler ---
        const welcomeOverlay = document.getElementById("welcome-overlay");
        const openInvitationBtn = document.getElementById("open-invitation-btn");

        if (welcomeOverlay && openInvitationBtn) {
            openInvitationBtn.addEventListener("click", function () {
                // Remove body overflow restriction to enable scrolling
                document.body.classList.remove("overflow-hidden");

                // Start playback unmuted if they haven't explicitly muted it
                if (!isMuted) {
                    bgMusic.muted = false;
                    bgMusic.play()
                        .then(() => {
                            updateUI(true);
                        })
                        .catch(err => console.log("Playback failed on button click:", err));
                }

                // Smoothly fade out content first, then the background for a premium portal effect
                if (window.gsap) {
                    const tl = gsap.timeline({
                        onComplete: () => {
                            welcomeOverlay.style.display = "none";
                        }
                    });

                    // 1. Fade out the inner content container with a subtle downward slide
                    tl.to(welcomeOverlay.querySelector(".max-w-md"), {
                        opacity: 0,
                        y: 40,
                        duration: 0.8,
                        ease: "power3.in"
                    });

                    // 2. Fade out the background backdrop smoothly
                    tl.to(welcomeOverlay, {
                        opacity: 0,
                        duration: 0.8,
                        ease: "power2.out"
                    }, "-=0.3"); // Overlap slightly for seamless transition
                } else {
                    welcomeOverlay.style.opacity = "0";
                    setTimeout(() => {
                        welcomeOverlay.style.display = "none";
                    }, 1000);
                }
            });
            // Staggered entrance animation for welcome screen elements on load
            if (window.gsap) {
                gsap.to(welcomeOverlay.querySelector(".max-w-md"), { opacity: 1, duration: 0.1 });
                gsap.from(welcomeOverlay.querySelectorAll(".welcome-animate"), {
                    opacity: 0,
                    y: 35,
                    stagger: 0.15,
                    duration: 1.2,
                    ease: "power3.out"
                });
            } else {
                welcomeOverlay.querySelector(".max-w-md").style.opacity = "1";
            }
        }

        // Auto-play attempt on first user interaction (only fallback if welcome screen is not present)
        function attemptAutoplay() {
            if (!isMuted && bgMusic.paused) {
                bgMusic.play()
                    .then(() => {
                        updateUI(true);
                        // Clean up listeners once played
                        removeInteractionListeners();
                    })
                    .catch(err => {
                        console.log("Autoplay blocked, waiting for user interaction.");
                    });
            } else if (isMuted) {
                updateUI(false);
                removeInteractionListeners();
            }
        }

        const interactions = ["click", "touchstart", "scroll", "keydown"];
        function removeInteractionListeners() {
            interactions.forEach(event => {
                document.removeEventListener(event, attemptAutoplay);
            });
        }

        // Only use generic autoplay event listeners if welcome screen is not active
        if (!welcomeOverlay) {
            interactions.forEach(event => {
                document.addEventListener(event, attemptAutoplay, { passive: true });
            });
            attemptAutoplay();
        }

        // Monitor playing state change manually for edge cases
        bgMusic.addEventListener("play", () => updateUI(true));
        bgMusic.addEventListener("pause", () => updateUI(false));

        // --- Save the Date Video Pause Action ---
        // 1. Native HTML5 video player
        const html5Video = document.getElementById("story-html5-video");
        if (html5Video) {
            html5Video.addEventListener("play", function() {
                bgMusic.pause();
                updateUI(false);
            });
        }

        // 2. YouTube Iframe Player API
        const youtubeIframe = document.getElementById("story-youtube-iframe");
        if (youtubeIframe) {
            // Load YT Player API script if not already present
            if (!window.YT) {
                const tag = document.createElement("script");
                tag.src = "https://www.youtube.com/iframe_api";
                const firstScriptTag = document.getElementsByTagName("script")[0];
                firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
            }

            // Function called when API is ready (or check if already loaded)
            window.onYouTubeIframeAPIReady = function() {
                initializeYTPlayer();
            };

            // If YT is already loaded (for instance, if another script loaded it)
            if (window.YT && window.YT.Player) {
                initializeYTPlayer();
            }

            function initializeYTPlayer() {
                new YT.Player("story-youtube-iframe", {
                    events: {
                        'onStateChange': function(event) {
                            // YT.PlayerState.PLAYING corresponds to 1
                            if (event.data === 1) {
                                bgMusic.pause();
                                updateUI(false);
                            }
                        }
                    }
                });
            }
        }
    }

});
