<?php
require_once 'auth.php';
require_once '../includes/db.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: faqs.php");
    exit;
}

// Fetch existing FAQ
$stmt = $pdo->prepare("SELECT * FROM faqs WHERE id = ?");
$stmt->execute([$id]);
$faq = $stmt->fetch();

if (!$faq) {
    $_SESSION['error'] = "FAQ not found.";
    header("Location: faqs.php");
    exit;
}

// Handle Update FAQ
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = trim($_POST['question'] ?? '');
    $answer = trim($_POST['answer'] ?? '');
    $sort_order = intval($_POST['sort_order'] ?? 0);
    $status = $_POST['status'] ?? 'active';

    if (!empty($question) && !empty($answer)) {
        try {
            $stmt = $pdo->prepare("UPDATE faqs SET question = ?, answer = ?, sort_order = ?, status = ? WHERE id = ?");
            if ($stmt->execute([$question, $answer, $sort_order, $status, $id])) {
                $_SESSION['success'] = "FAQ updated successfully.";
                header("Location: faqs.php");
                exit;
            } else {
                $error = "Failed to update FAQ.";
            }
        } catch (\PDOException $e) {
            $error = "A database error occurred: " . $e->getMessage();
        }
    } else {
        $error = "Both Question and Answer fields are required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit FAQ - <?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-blue-900 p-4 text-white flex justify-between items-center shadow-lg">
        <div class="flex items-center gap-8">
            <h1 class="text-xl font-bold">Admin Dashboard</h1>
            <a href="faqs.php" class="text-sm hover:underline flex items-center gap-1">
                <span class="material-symbols-outlined text-sm">arrow_back</span>
                Back to FAQs
            </a>
        </div>
        <div class="flex items-center gap-4">
            <a href="change_password.php" class="text-sm hover:underline">Change Password</a>
            <a href="logout.php" class="text-sm hover:underline">Logout</a>
        </div>
    </nav>

    <div class="container mx-auto p-8 max-w-2xl">
        <div class="bg-white rounded-xl shadow-xl overflow-hidden">
            <div class="bg-blue-600 p-6 text-white">
                <h3 class="text-2xl font-bold flex items-center gap-3">
                    <span class="material-symbols-outlined">edit_note</span>
                    Edit FAQ
                </h3>
                <p class="opacity-80 text-sm mt-1">Update frequently asked question details</p>
            </div>

            <form action="" method="POST" class="p-8 space-y-6">
                <?php if (isset($error)): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4 rounded shadow-sm" role="alert">
                        <p><?= $error ?></p>
                    </div>
                <?php endif; ?>

                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Question</label>
                    <input type="text" name="question" required value="<?= htmlspecialchars($faq['question']) ?>" 
                           class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Answer</label>
                    <textarea name="answer" rows="5" required 
                              class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"><?= htmlspecialchars($faq['answer']) ?></textarea>
                </div>

                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Status</label>
                        <select name="status" required 
                                class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all appearance-none bg-white">
                            <option value="active" <?= $faq['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $faq['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Sort Order</label>
                        <input type="number" name="sort_order" required value="<?= htmlspecialchars($faq['sort_order']) ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                    </div>
                </div>

                <div class="flex gap-4 pt-4">
                    <button type="submit" 
                            class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-200 shadow-md">
                        Save Changes
                    </button>
                    <a href="faqs.php" 
                       class="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 px-6 rounded-lg text-center transition duration-200 border border-gray-200">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
