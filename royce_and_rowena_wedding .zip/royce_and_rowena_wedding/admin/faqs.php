<?php
require_once 'auth.php';
require_once '../includes/db.php';

// Fetch all FAQs ordered by sort_order
$stmt = $pdo->query("SELECT * FROM faqs ORDER BY sort_order ASC, id DESC");
$faqs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage FAQs - <?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>">
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-blue-900 p-4 text-white flex justify-between items-center shadow-lg">
        <div class="flex items-center gap-4">
            <a href="index.php" class="hover:text-blue-200 transition-colors flex items-center">
                <span class="material-symbols-outlined align-middle">arrow_back</span>
            </a>
            <h1 class="text-xl font-bold">FAQs Manager</h1>
        </div>
        <div class="flex items-center gap-8">
            <a href="index.php" class="text-sm hover:underline">Dashboard</a>
            <a href="media.php" class="text-sm hover:underline">Media Manager</a>
            <a href="settings.php" class="text-sm hover:underline">Website Settings</a>
            <a href="change_password.php" class="text-sm hover:underline">Change Password</a>
            <a href="logout.php" class="text-sm hover:underline">Logout</a>
        </div>
    </nav>

    <div class="container mx-auto p-8">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm flex items-center gap-3">
                <span class="material-symbols-outlined">check_circle</span>
                <p><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded shadow-sm flex items-center gap-3">
                <span class="material-symbols-outlined">error</span>
                <p><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
            </div>
        <?php endif; ?>

        <div class="flex justify-between items-center mb-6">
            <h3 class="text-2xl font-bold text-gray-800">Frequently Asked Questions</h3>
            <a href="add_faq.php" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-6 rounded-lg inline-flex items-center transition duration-200 shadow-md">
                <span class="material-symbols-outlined mr-2">add</span>
                Add New FAQ
            </a>
        </div>

        <div class="bg-white rounded-xl shadow-md overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600 w-16">Order</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600">Question</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600">Answer</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600 w-24">Status</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600 text-right w-32">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($faqs as $faq): ?>
                    <tr class="border-t hover:bg-gray-50">
                        <td class="py-4 px-4 font-mono text-gray-500 font-bold"><?= htmlspecialchars($faq['sort_order']) ?></td>
                        <td class="py-4 px-4 font-semibold text-blue-900"><?= htmlspecialchars($faq['question']) ?></td>
                        <td class="py-4 px-4 text-sm text-gray-600 max-w-md truncate" title="<?= htmlspecialchars($faq['answer']) ?>">
                            <?= htmlspecialchars($faq['answer']) ?>
                        </td>
                        <td class="py-4 px-4">
                            <span class="<?= $faq['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700' ?> px-3 py-1 rounded-full text-xs font-bold uppercase">
                                <?= htmlspecialchars($faq['status']) ?>
                            </span>
                        </td>
                        <td class="py-4 px-4 text-right whitespace-nowrap">
                            <a href="edit_faq.php?id=<?= $faq['id'] ?>" class="text-blue-600 hover:text-blue-900 transition-colors duration-200 mr-4 inline-block" title="Edit FAQ">
                                <span class="material-symbols-outlined text-xl">edit</span>
                            </a>
                            <a href="delete_faq.php?id=<?= $faq['id'] ?>" 
                               class="text-red-500 hover:text-red-700 transition-colors duration-200 inline-block" 
                               title="Delete FAQ"
                               onclick="return confirm('Are you sure you want to delete this FAQ?');">
                                <span class="material-symbols-outlined text-xl">delete</span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if (empty($faqs)): ?>
                <div class="p-8 text-center text-gray-500 italic">
                    <span class="material-symbols-outlined text-4xl mb-2 opacity-50">quiz</span>
                    <p>No FAQs added yet. Click "Add New FAQ" to create one.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
