<?php
require_once 'auth.php';
require_once '../includes/db.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM rsvps WHERE id = ?");
        if ($stmt->execute([$id])) {
            $_SESSION['success'] = "RSVP deleted successfully.";
        } else {
            $_SESSION['error'] = "Failed to delete RSVP.";
        }
    } catch (\PDOException $e) {
        $_SESSION['error'] = "A database error occurred.";
    }
}

header("Location: index.php");
exit;
?>
