<?php
require_once 'auth.php';
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if POST was truncated due to exceeding post_max_size
    if (empty($_POST) && $_SERVER['CONTENT_LENGTH'] > 0) {
        $max_size = ini_get('post_max_size');
        $_SESSION['error'] = "Upload failed. The file is too large. The maximum POST size allowed by the server is {$max_size}.";
        header("Location: media.php");
        exit;
    }

    $category = $_POST['category'] ?? 'gallery';
    $alt_text = $_POST['alt_text'] ?? '';
    
    if (isset($_FILES['image'])) {
        $error_code = $_FILES['image']['error'];
        if ($error_code === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['image']['tmp_name'];
            $fileName = $_FILES['image']['name'];
            $fileSize = $_FILES['image']['size'];
            $fileType = $_FILES['image']['type'];
            $fileNameCmps = explode(".", $fileName);
            $fileExtension = strtolower(end($fileNameCmps));
            
            $is_video = ($category === 'pre_wedding_video' || $category === 'rsvp_bg_video');
            $is_audio = ($category === 'background_music');
            if ($is_video) {
                $allowedfileExtensions = array('mp4', 'webm', 'ogg', 'mov');
                $uploadFileDir = '../assets/videos/';
                $db_path_prefix = 'assets/videos/';
            } elseif ($is_audio) {
                $allowedfileExtensions = array('mp3', 'wav', 'ogg', 'm4a', 'aac');
                $uploadFileDir = '../assets/audio/';
                $db_path_prefix = 'assets/audio/';
            } else {
                $allowedfileExtensions = array('jpg', 'jpeg', 'png', 'gif', 'webp');
                $uploadFileDir = '../assets/images/';
                $db_path_prefix = 'assets/images/';
            }
            
            if (in_array($fileExtension, $allowedfileExtensions)) {
                if (!is_dir($uploadFileDir)) {
                    mkdir($uploadFileDir, 0755, true);
                }
                
                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                $dest_path = $uploadFileDir . $newFileName;
                $db_path = $db_path_prefix . $newFileName;
                
                if(move_uploaded_file($fileTmpPath, $dest_path)) {
                    if ($is_video || $is_audio) {
                        // Delete old video/audio in this category from DB and filesystem
                        $stmt = $pdo->prepare("SELECT * FROM media WHERE category = ?");
                        $stmt->execute([$category]);
                        $old_files = $stmt->fetchAll();
                        foreach ($old_files as $old_f) {
                            $old_path = '../' . $old_f['file_path'];
                            if (file_exists($old_path)) {
                                unlink($old_path);
                            }
                        }
                        $stmt = $pdo->prepare("DELETE FROM media WHERE category = ?");
                        $stmt->execute([$category]);
                    }

                    // Get max sort_order
                    $stmt = $pdo->prepare("SELECT MAX(sort_order) as max_order FROM media WHERE category = ?");
                    $stmt->execute([$category]);
                    $max_order = $stmt->fetch()['max_order'] ?? 0;
                    $new_order = $max_order + 1;
                    
                    $stmt = $pdo->prepare("INSERT INTO media (file_path, category, alt_text, sort_order) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$db_path, $category, $alt_text, $new_order]);
                    
                    $_SESSION['success'] = $is_video ? "Video uploaded successfully." : "Image uploaded successfully.";
                } else {
                    $_SESSION['error'] = "There was some error moving the file to the upload directory. Check folder permissions.";
                }
            } else {
                $_SESSION['error'] = "Upload failed. Allowed file types: " . implode(', ', $allowedfileExtensions);
            }
        } else {
            switch ($error_code) {
                case UPLOAD_ERR_INI_SIZE:
                    $max_upload = ini_get('upload_max_filesize');
                    $_SESSION['error'] = "Upload failed. The file is too large. The maximum file size allowed by the server is {$max_upload}.";
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    $_SESSION['error'] = "Upload failed. The file exceeds the maximum size specified in the HTML form.";
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $_SESSION['error'] = "Upload failed. The file was only partially uploaded. Please try again.";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $_SESSION['error'] = "Upload failed. No file was selected for upload.";
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    $_SESSION['error'] = "Upload failed. Server error: Missing temporary directory.";
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    $_SESSION['error'] = "Upload failed. Server error: Failed to write file to disk.";
                    break;
                case UPLOAD_ERR_EXTENSION:
                    $_SESSION['error'] = "Upload failed. Server error: A PHP extension stopped the file upload.";
                    break;
                default:
                    $_SESSION['error'] = "Upload failed with error code: {$error_code}.";
                    break;
            }
        }
    } else {
        $_SESSION['error'] = "No file uploaded or form submission was incomplete.";
    }
    header("Location: media.php");
    exit;
}
?>
