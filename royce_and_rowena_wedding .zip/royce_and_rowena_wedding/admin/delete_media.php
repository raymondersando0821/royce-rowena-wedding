<?php
require_once 'auth.php';
require_once '../includes/db.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    // Fetch record
    $stmt = $pdo->prepare("SELECT file_path FROM media WHERE id = ?");
    $stmt->execute([$id]);
    $media = $stmt->fetch();
    
    if ($media) {
        $filePath = '../' . $media['file_path'];
        
        // Only attempt to delete file if it's not a URL
        if (!filter_var($media['file_path'], FILTER_VALIDATE_URL)) {
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }
        
        // Delete from database regardless of file existence
        $stmt = $pdo->prepare("DELETE FROM media WHERE id = ?");
        if ($stmt->execute([$id])) {
            $_SESSION['success'] = "Media deleted successfully.";
        } else {
            $_SESSION['error'] = "Failed to delete from database.";
        }
    } else {
        $_SESSION['error'] = "Image not found.";
    }
}

header("Location: media.php");
exit;
?>
