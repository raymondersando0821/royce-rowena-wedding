<?php
require_once '../includes/db.php';

$hash = password_hash('admin123', PASSWORD_DEFAULT);
$stmt = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE username = 'admin'");
$stmt->execute([$hash]);

echo "Admin password updated successfully. You can now log in with admin / admin123";
echo "<br><a href='login.php'>Go to Login</a>";
