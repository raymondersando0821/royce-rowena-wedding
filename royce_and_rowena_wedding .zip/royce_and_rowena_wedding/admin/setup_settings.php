<?php
// admin/setup_settings.php
require_once __DIR__ . '/../includes/db.php';

// Only allow logged in admin or terminal execution
if (php_sapi_name() !== 'cli') {
    require_once __DIR__ . '/auth.php';
}

echo "Initializing Website Settings database table...\n";

try {
    // 1. Create table
    $sql = "CREATE TABLE IF NOT EXISTS site_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value TEXT NULL,
        setting_label VARCHAR(255) NOT NULL,
        setting_section VARCHAR(50) NOT NULL,
        setting_type VARCHAR(20) DEFAULT 'text',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    $pdo->exec($sql);
    echo "✅ Table 'site_settings' verified/created.\n";

    // 2. Default settings dataset
    $default_settings = [
        // General & Hero
        [
            'site_title',
            'Royce & Rowena Wedding',
            'Website Title / Couple Names',
            'General',
            'text'
        ],
        [
            'wedding_date',
            'August 21, 2026',
            'Wedding Date',
            'General',
            'text'
        ],
        [
            'hero_tagline',
            'SAVE THE DATE',
            'Hero Tagline (Above names)',
            'Hero Section',
            'text'
        ],
        [
            'hero_locations',
            'LOKAL NG TRECE MARTIRES CITY • PRECIOUS GARDEN EVENTS PLACE',
            'Hero Location / Sub-text',
            'Hero Section',
            'text'
        ],

        // Pre-Wedding Video / Story
        [
            'video_section_subtitle',
            'PRE-WEDDING VIDEO',
            'Section Subtitle',
            'Story & Video',
            'text'
        ],
        [
            'video_section_title',
            'Our Pre-Wedding Video',
            'Section Title',
            'Story & Video',
            'text'
        ],
        [
            'video_description',
            "A celebration of our journey leading up to this special day. We captured these moments to share our joy, love, and anticipation with all of you.\n\nSit back, relax, and enjoy a glimpse into our story and the lifetime of love that lies ahead of us. We are so excited to celebrate with you!",
            'Story / Video Description Paragraphs',
            'Story & Video',
            'textarea'
        ],
        [
            'video_youtube_link',
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'Pre-Wedding Video YouTube Link',
            'Story & Video',
            'text'
        ],

        // Venue & Celebration
        [
            'venue_section_subtitle',
            'THE CELEBRATION',
            'Section Subtitle',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_section_title',
            'Save the Date',
            'Section Title',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_ceremony_title',
            'The Ceremony',
            'Ceremony Card Title',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_ceremony_name',
            'Iglesia Ni Cristo Lokal ng Trece Martires City',
            'Ceremony Venue Name',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_ceremony_time',
            "Two O'Clock (2PM) in the Afternoon",
            'Ceremony Time Text',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_ceremony_maps_url',
            'https://maps.app.goo.gl/iZZWxB1GoanBz8BR9',
            'Ceremony Google Maps URL',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_reception_title',
            'The Reception',
            'Reception Card Title',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_reception_name',
            'Precious Garden Events Place',
            'Reception Venue Name',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_reception_time',
            "Four O'Clock (4PM) in the Afternoon",
            'Reception Time Text',
            'Celebration & Venue',
            'text'
        ],
        [
            'venue_reception_maps_url',
            'https://maps.app.goo.gl/zKEA2wewnyRxkFLu6',
            'Reception Google Maps URL',
            'Celebration & Venue',
            'text'
        ],

        // Gallery
        [
            'gallery_subtitle',
            'MOMENTS',
            'Section Subtitle',
            'Gallery',
            'text'
        ],
        [
            'gallery_title',
            'Gallery',
            'Section Title',
            'Gallery',
            'text'
        ],
        [
            'gallery_button_text',
            'See more pictures',
            'Expand Button Text',
            'Gallery',
            'text'
        ],

        // Dress Code & Other Details
        [
            'attire_subtitle',
            'DRESS CODE',
            'Dress Code Subtitle',
            'Attire & Details',
            'text'
        ],
        [
            'attire_title',
            'Formal Attire',
            'Dress Code Title',
            'Attire & Details',
            'text'
        ],
        [
            'details_subtitle',
            'INVITATION DETAILS',
            'Other Details Subtitle',
            'Attire & Details',
            'text'
        ],
        [
            'details_title',
            'Other Details',
            'Other Details Title',
            'Attire & Details',
            'text'
        ],
        [
            'details_description',
            'We have reserved 1 seat just for you. Please confirm your attendance through our wedding website. Kindly RSVP on or before August 3, 2026 .',
            'Seat Limit / RSVP Date Description',
            'Attire & Details',
            'textarea'
        ],

        // FAQ Section
        [
            'faq_subtitle',
            'HAVE QUESTIONS?',
            'FAQ Section Subtitle',
            'FAQ Section',
            'text'
        ],
        [
            'faq_title',
            'Frequently Asked Questions',
            'FAQ Section Title',
            'FAQ Section',
            'text'
        ],
        [
            'faq_description',
            'We have compiled answers to some of the most common questions of our guests. If you can\'t find what you need, feel free to reach out.',
            'FAQ Section Description',
            'FAQ Section',
            'textarea'
        ],

        // RSVP Section
        [
            'rsvp_title',
            'Kindly Respond',
            'RSVP Form Section Title',
            'RSVP Section',
            'text'
        ],
        [
            'rsvp_enabled',
            '1',
            'Enable / Disable RSVP Form Submissions',
            'RSVP Section',
            'select'
        ],
        [
            'rsvp_disabled_message',
            'Thank you for your interest! RSVP submissions for our wedding are currently closed.',
            'Message Displayed When RSVP Is Disabled',
            'RSVP Section',
            'textarea'
        ],

        // Registry & Gift Guide
        [
            'gift_subtitle',
            '- - - - - - -',
            'Gift Guide Subtitle',
            'Registry & Gift',
            'text'
        ],
        [
            'gift_title',
            'Gift Guide',
            'Gift Guide Title',
            'Registry & Gift',
            'text'
        ],
        [
            'gift_description',
            "Your presence and prayers are the greatest gifts we could ask for. However, if you wish to bless us further, a monetary gift would be sincerely appreciated as we begin our new journey together.",
            'Gift Guide Main Text Description',
            'Registry & Gift',
            'textarea'
        ],
        [
            'gift_banking_title',
            'Gift via Banking / QR Code',
            'Banking Sub-Section Title',
            'Registry & Gift',
            'text'
        ],
        [
            'gift_button_text',
            'See QR Codes',
            'Toggle QR Button Text',
            'Registry & Gift',
            'text'
        ],
        [
            'gift_qr_footer',
            'Scan any of the QR codes above to send your gift. We are truly grateful for your support!',
            'Banking QR Guide Footer Text',
            'Registry & Gift',
            'textarea'
        ]
    ];

    // 3. Insert or update without modifying existing user changes
    $stmt = $pdo->prepare("INSERT INTO site_settings (setting_key, setting_value, setting_label, setting_section, setting_type) 
        VALUES (?, ?, ?, ?, ?) 
        ON DUPLICATE KEY UPDATE 
            setting_label = VALUES(setting_label), 
            setting_section = VALUES(setting_section), 
            setting_type = VALUES(setting_type)");

    $inserted_count = 0;
    foreach ($default_settings as $setting) {
        $stmt->execute($setting);
        $inserted_count++;
    }

    echo "✅ Seeded $inserted_count settings items in database.\n";
    
    if (php_sapi_name() !== 'cli') {
        $_SESSION['success'] = "Website settings table successfully initialized/seeded with $inserted_count items!";
        header("Location: index.php");
        exit;
    }

} catch (\PDOException $e) {
    echo "❌ Error setting up settings table: " . $e->getMessage() . "\n";
    if (php_sapi_name() !== 'cli') {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
        header("Location: index.php");
        exit;
    }
}
?>
