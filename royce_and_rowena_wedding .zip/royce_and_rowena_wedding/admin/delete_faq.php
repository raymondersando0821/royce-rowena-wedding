<?php
require_once 'auth.php';
require_once '../includes/db.php';

$id = $_GET['id'] ?? null;
if ($id) {
    try {
        $stmt = $pdo->prepare("DELETE FROM faqs WHERE id = ?");
        if ($stmt->execute([$id])) {
            $_SESSION['success'] = "FAQ deleted successfully.";
        } else {
            $_SESSION['error'] = "Failed to delete FAQ.";
        }
    } catch (\PDOException $e) {
        $_SESSION['error'] = "A database error occurred: " . $e->getMessage();
    }
}
header("Location: faqs.php");
exit;
?>
