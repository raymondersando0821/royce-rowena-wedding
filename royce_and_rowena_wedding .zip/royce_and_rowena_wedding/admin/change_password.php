<?php
require_once 'auth.php';
require_once '../includes/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = 'All fields are required.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'New passwords do not match.';
    } elseif (strlen($new_password) < 6) {
        $error = 'New password must be at least 6 characters long.';
    } else {
        // Fetch user from DB to verify current password
        $stmt = $pdo->prepare("SELECT password_hash FROM admin_users WHERE username = ?");
        $stmt->execute([$_SESSION['admin_username']]);
        $user = $stmt->fetch();

        if ($user && password_verify($current_password, $user['password_hash'])) {
            // Update password
            $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $update_stmt = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE username = ?");
            if ($update_stmt->execute([$new_hash, $_SESSION['admin_username']])) {
                $success = 'Password changed successfully.';
            } else {
                $error = 'Failed to update password in database.';
            }
        } else {
            $error = 'Incorrect current password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - <?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    <link rel="icon" type="image/png" href="../assets/images/logo.png">
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-blue-900 p-4 text-white flex justify-between items-center shadow-lg">
        <div class="flex items-center gap-8">
            <h1 class="text-xl font-bold">Admin Dashboard</h1>
            <a href="index.php" class="text-sm hover:underline flex items-center gap-1">
                <span class="material-symbols-outlined text-sm">arrow_back</span>
                Back to Dashboard
            </a>
        </div>
        <div class="flex items-center gap-4">
            <a href="change_password.php" class="text-sm hover:underline font-bold">Change Password</a>
            <a href="logout.php" class="text-sm hover:underline">Logout (<?= htmlspecialchars($_SESSION['admin_username']) ?>)</a>
        </div>
    </nav>

    <div class="container mx-auto p-8 max-w-md mt-10">
        <div class="bg-white rounded-xl shadow-xl overflow-hidden">
            <div class="bg-blue-600 p-6 text-white text-center">
                <h3 class="text-2xl font-bold flex items-center justify-center gap-2">
                    <span class="material-symbols-outlined">lock_reset</span>
                    Change Password
                </h3>
            </div>

            <form method="POST" class="p-8 space-y-6">
                <?php if ($error): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                        <p><?= htmlspecialchars($error) ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                        <p><?= htmlspecialchars($success) ?></p>
                    </div>
                <?php endif; ?>

                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Current Password</label>
                    <input type="password" name="current_password" required 
                           class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">New Password</label>
                    <input type="password" name="new_password" required minlength="6"
                           class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                </div>
                
                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Confirm New Password</label>
                    <input type="password" name="confirm_password" required minlength="6"
                           class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                </div>

                <div class="pt-2">
                    <button type="submit" 
                            class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200 shadow-md">
                        Update Password
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
