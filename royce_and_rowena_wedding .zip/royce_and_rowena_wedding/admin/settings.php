<?php
// admin/settings.php
require_once 'auth.php';
require_once '../includes/db.php';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $messages = [];
    
    // Handle logo upload if provided
    if (isset($_FILES['website_logo']) && $_FILES['website_logo']['error'] === UPLOAD_ERR_OK) {
        $fileTmp = $_FILES['website_logo']['tmp_name'];
        $fileName = $_FILES['website_logo']['name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedExts = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg'];
        
        if (in_array($fileExt, $allowedExts)) {
            $targetDir = __DIR__ . '/../assets/images/';
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            $targetPath = $targetDir . 'logo.png';
            if (move_uploaded_file($fileTmp, $targetPath)) {
                $messages[] = "Website logo uploaded successfully!";
            } else {
                $_SESSION['error'] = "Failed to save uploaded logo file.";
            }
        } else {
            $_SESSION['error'] = "Invalid image type for logo. Allowed: PNG, JPG, JPEG, WEBP, GIF, SVG.";
        }
    }

    if (isset($_POST['settings']) && is_array($_POST['settings'])) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("UPDATE site_settings SET setting_value = ? WHERE setting_key = ?");
            foreach ($_POST['settings'] as $key => $value) {
                $stmt->execute([$value, $key]);
            }
            $pdo->commit();
            $messages[] = "Website settings updated successfully!";
        } catch (\Exception $e) {
            $pdo->rollBack();
            $_SESSION['error'] = "Failed to update settings: " . $e->getMessage();
        }
    }
    
    if (!empty($messages) && !isset($_SESSION['error'])) {
        $_SESSION['success'] = implode(" ", $messages);
    }
    
    $active_tab = $_POST['active_tab'] ?? 'General';
    header("Location: settings.php?tab=" . urlencode($active_tab));
    exit;
}

// Fetch all settings
$stmt = $pdo->query("SELECT * FROM site_settings ORDER BY setting_key ASC");
$all_settings = $stmt->fetchAll();

// Group settings by section
$grouped_settings = [];
foreach ($all_settings as $setting) {
    $grouped_settings[$setting['setting_section']][] = $setting;
}

// Define tab list with order and icons
$tabs_info = [
    'General' => ['icon' => 'settings', 'label' => 'General Settings'],
    'Hero Section' => ['icon' => 'splitscreen', 'label' => 'Hero Banner'],
    'Story & Video' => ['icon' => 'videocam', 'label' => 'Story & Video'],
    'Celebration & Venue' => ['icon' => 'church', 'label' => 'Venue Details'],
    'Gallery' => ['icon' => 'imagesmode', 'label' => 'Gallery Headings'],
    'Attire & Details' => ['icon' => 'checkroom', 'label' => 'Dress Code & Details'],
    'FAQ Section' => ['icon' => 'quiz', 'label' => 'FAQ Introduction'],
    'RSVP Section' => ['icon' => 'mail', 'label' => 'RSVP Section'],
    'Registry & Gift' => ['icon' => 'featured_play_list', 'label' => 'Gift Guide']
];

// Determine active tab
$current_tab = $_GET['tab'] ?? 'General';
if (!array_key_exists($current_tab, $tabs_info)) {
    $current_tab = 'General';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Settings - <?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>">
</head>
<body class="bg-gray-100 min-h-screen">
    <!-- Navbar -->
    <nav class="bg-blue-900 p-4 text-white flex justify-between items-center shadow-lg">
        <div class="flex items-center gap-4">
            <a href="index.php" class="hover:text-blue-200 transition-colors flex items-center">
                <span class="material-symbols-outlined align-middle">arrow_back</span>
            </a>
            <h1 class="text-xl font-bold flex items-center gap-2">
                <span class="material-symbols-outlined">settings</span>
                Website Settings
            </h1>
        </div>
        <div class="flex items-center gap-8">
            <a href="index.php" class="text-sm hover:underline">Dashboard</a>
            <a href="media.php" class="text-sm hover:underline">Media Manager</a>
            <a href="faqs.php" class="text-sm hover:underline">FAQs Manager</a>
            <a href="change_password.php" class="text-sm hover:underline">Change Password</a>
            <a href="logout.php" class="text-sm hover:underline">Logout (<?= htmlspecialchars($_SESSION['admin_username']) ?>)</a>
        </div>
    </nav>

    <div class="container mx-auto p-8">
        <!-- Success/Error Alerts -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm flex items-center gap-3">
                <span class="material-symbols-outlined text-green-600">check_circle</span>
                <p><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded shadow-sm flex items-center gap-3">
                <span class="material-symbols-outlined text-red-600">error</span>
                <p><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
            </div>
        <?php endif; ?>

        <!-- Main Layout Split -->
        <div class="flex flex-col md:flex-row gap-8">
            <!-- Sidebar Navigation -->
            <div class="w-full md:w-1/4 bg-white rounded-xl shadow-md p-4 self-start">
                <h3 class="text-xs font-bold text-gray-400 uppercase tracking-widest px-3 mb-3">Settings Categories</h3>
                <nav class="space-y-1">
                    <?php foreach ($tabs_info as $tab_key => $tab): ?>
                        <a href="?tab=<?= urlencode($tab_key) ?>" 
                           class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all duration-150 <?= $current_tab === $tab_key ? 'bg-blue-900 text-white shadow' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900' ?>">
                            <span class="material-symbols-outlined text-xl"><?= $tab['icon'] ?></span>
                            <?= htmlspecialchars($tab['label']) ?>
                        </a>
                    <?php endforeach; ?>
                </nav>
            </div>

            <!-- Settings Content Panel -->
            <div class="w-full md:w-3/4">
                <div class="bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="bg-blue-600 p-6 text-white flex items-center gap-3">
                        <span class="material-symbols-outlined text-3xl"><?= $tabs_info[$current_tab]['icon'] ?></span>
                        <div>
                            <h2 class="text-xl font-bold"><?= htmlspecialchars($tabs_info[$current_tab]['label']) ?></h2>
                            <p class="text-blue-100 text-xs mt-0.5">Edit text fields displayed in the <?= htmlspecialchars(strtolower($current_tab)) ?> section of the website.</p>
                        </div>
                    </div>

                    <form action="" method="POST" enctype="multipart/form-data" class="p-8 space-y-6">
                        <input type="hidden" name="active_tab" value="<?= htmlspecialchars($current_tab) ?>">

                        <?php if ($current_tab === 'General'): ?>
                            <!-- Logo Upload Box -->
                            <div class="space-y-3 border-b border-gray-200 pb-6 mb-6">
                                <div class="flex justify-between items-center">
                                    <label class="block text-gray-800 font-bold text-sm tracking-wide uppercase">
                                        Website Logo / Favicon
                                    </label>
                                    <span class="text-[10px] font-mono bg-blue-50 text-blue-600 px-2 py-0.5 rounded border border-blue-200">
                                        assets/images/logo.png
                                    </span>
                                </div>
                                
                                <div class="flex flex-col sm:flex-row items-center gap-6 p-4 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                                    <div class="flex flex-col items-center">
                                        <p class="text-xs text-gray-500 mb-2 font-semibold">Current Logo</p>
                                        <?php 
                                        $logo_file = __DIR__ . '/../assets/images/logo.png';
                                        $logo_ver = file_exists($logo_file) ? filemtime($logo_file) : time();
                                        ?>
                                        <div class="p-2 bg-white rounded-full ring-2 ring-amber-300 shadow-md">
                                            <img src="../assets/images/logo.png?v=<?= $logo_ver ?>" alt="Website Logo" class="h-16 w-16 object-cover rounded-full">
                                        </div>
                                    </div>
                                    
                                    <div class="flex-1 w-full space-y-2">
                                        <label class="block text-xs font-semibold text-gray-700">Upload New Logo Image</label>
                                        <input type="file" name="website_logo" accept="image/png, image/jpeg, image/webp, image/gif, image/svg+xml" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer border border-gray-300 rounded-lg bg-white">
                                        <p class="text-[11px] text-gray-500">Supported formats: PNG, JPG, WEBP, SVG. Automatically replaces existing logo across the entire site.</p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="space-y-6">
                            <?php if (isset($grouped_settings[$current_tab])): ?>
                                <?php foreach ($grouped_settings[$current_tab] as $setting): ?>
                                    <div class="space-y-2 border-b border-gray-100 pb-5 last:border-0 last:pb-0">
                                        <div class="flex justify-between items-center">
                                            <label class="block text-gray-800 font-bold text-sm tracking-wide uppercase">
                                                <?= htmlspecialchars($setting['setting_label']) ?>
                                            </label>
                                            <span class="text-[10px] font-mono bg-gray-100 text-gray-500 px-2 py-0.5 rounded border">
                                                key: <?= htmlspecialchars($setting['setting_key']) ?>
                                            </span>
                                        </div>
                                        
                                        <?php if ($setting['setting_key'] === 'rsvp_enabled' || $setting['setting_type'] === 'select'): ?>
                                            <select name="settings[<?= htmlspecialchars($setting['setting_key']) ?>]" 
                                                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all font-sans text-sm text-gray-700 bg-white font-bold">
                                                <option value="1" <?= ($setting['setting_value'] ?? '1') == '1' ? 'selected' : '' ?>>✅ Enabled (RSVP Form Open & Accepting Submissions)</option>
                                                <option value="0" <?= ($setting['setting_value'] ?? '1') == '0' ? 'selected' : '' ?>>🚫 Disabled (RSVP Submissions Closed)</option>
                                            </select>
                                            <p class="text-xs text-gray-500 mt-1">Select whether guests can submit RSVPs on the website.</p>
                                        <?php elseif ($setting['setting_type'] === 'textarea'): ?>
                                            <textarea name="settings[<?= htmlspecialchars($setting['setting_key']) ?>]" 
                                                      rows="4" 
                                                      class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all font-sans text-sm text-gray-700 placeholder-gray-400"
                                                      placeholder="Enter text..."><?= htmlspecialchars($setting['setting_value'] ?? '') ?></textarea>
                                        <?php else: ?>
                                            <input type="text" 
                                                   name="settings[<?= htmlspecialchars($setting['setting_key']) ?>]" 
                                                   value="<?= htmlspecialchars($setting['setting_value'] ?? '') ?>"
                                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all font-sans text-sm text-gray-700 placeholder-gray-400"
                                                   placeholder="Enter text...">
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="text-gray-500 italic py-4">No settings configured for this section yet.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Form Actions -->
                        <div class="flex items-center justify-end gap-4 pt-6 border-t">
                            <a href="index.php" class="px-6 py-2.5 rounded-lg border border-gray-300 text-gray-700 font-bold text-sm hover:bg-gray-50 transition-colors">
                                Cancel
                            </a>
                            <button type="submit" class="px-8 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-colors flex items-center gap-2">
                                <span class="material-symbols-outlined text-sm">save</span>
                                Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
