<?php
require_once 'auth.php';
require_once '../includes/db.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit;
}

// Fetch existing RSVP
$stmt = $pdo->prepare("SELECT * FROM rsvps WHERE id = ?");
$stmt->execute([$id]);
$rsvp = $stmt->fetch();

if (!$rsvp) {
    $_SESSION['error'] = "RSVP not found.";
    header("Location: index.php");
    exit;
}

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $attendance = $_POST['attendance'] ?? '';
    $contact_number = trim($_POST['contact_number'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (!empty($full_name) && !empty($attendance) && !empty($contact_number)) {
        try {
            $stmt = $pdo->prepare("UPDATE rsvps SET full_name = ?, attendance = ?, contact_number = ?, message = ? WHERE id = ?");
            if ($stmt->execute([$full_name, $attendance, $contact_number, $message, $id])) {
                $_SESSION['success'] = "RSVP updated successfully.";
                header("Location: index.php");
                exit;
            } else {
                $error = "Failed to update RSVP.";
            }
        } catch (\PDOException $e) {
            $error = "A database error occurred.";
        }
    } else {
        $error = "Full Name, Attendance, and Contact Number are required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit RSVP - <?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-blue-900 p-4 text-white flex justify-between items-center shadow-lg">
        <div class="flex items-center gap-8">
            <h1 class="text-xl font-bold">Admin Dashboard</h1>
            <a href="index.php" class="text-sm hover:underline flex items-center gap-1">
                <span class="material-symbols-outlined text-sm">arrow_back</span>
                Back to Dashboard
            </a>
        </div>
        <div class="flex items-center gap-4">
            <a href="change_password.php" class="text-sm hover:underline">Change Password</a>
            <a href="logout.php" class="text-sm hover:underline">Logout</a>
        </div>
    </nav>

    <div class="container mx-auto p-8 max-w-2xl">
        <div class="bg-white rounded-xl shadow-xl overflow-hidden">
            <div class="bg-blue-600 p-6 text-white">
                <h3 class="text-2xl font-bold flex items-center gap-3">
                    <span class="material-symbols-outlined">edit_note</span>
                    Edit Guest RSVP
                </h3>
                <p class="opacity-80 text-sm mt-1">Update response details for <?= htmlspecialchars($rsvp['full_name']) ?></p>
            </div>

            <form action="" method="POST" class="p-8 space-y-6">
                <?php if (isset($error)): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                        <p><?= $error ?></p>
                    </div>
                <?php endif; ?>

                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Full Name</label>
                    <input type="text" name="full_name" required value="<?= htmlspecialchars($rsvp['full_name']) ?>" 
                           class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                </div>

                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Attendance</label>
                        <select name="attendance" required 
                                class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all appearance-none bg-white">
                            <option value="Yes" <?= $rsvp['attendance'] === 'Yes' ? 'selected' : '' ?>>Attending</option>
                            <option value="No" <?= $rsvp['attendance'] === 'No' ? 'selected' : '' ?>>Declined</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Contact Number</label>
                        <input type="text" name="contact_number" required value="<?= htmlspecialchars($rsvp['contact_number']) ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2 uppercase tracking-wide">Message</label>
                    <textarea name="message" rows="4" 
                              class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"><?= htmlspecialchars($rsvp['message'] ?? '') ?></textarea>
                </div>

                <div class="flex gap-4 pt-4">
                    <button type="submit" 
                            class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-200 shadow-md">
                        Save Changes
                    </button>
                    <a href="index.php" 
                       class="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 px-6 rounded-lg text-center transition duration-200 border border-gray-200">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
