<?php
require_once '../includes/db.php';

$newPassword = 'admin123';
$newHash = password_hash($newPassword, PASSWORD_DEFAULT);

// Update or insert admin user
$stmt = $pdo->prepare("SELECT COUNT(*) FROM admin_users WHERE username = 'admin'");
$stmt->execute();
$exists = $stmt->fetchColumn();

if ($exists) {
    $stmt = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE username = 'admin'");
    $stmt->execute([$newHash]);
    echo "<p style='color:green;font-size:18px;'>✅ Password updated successfully!</p>";
} else {
    $stmt = $pdo->prepare("INSERT INTO admin_users (username, password_hash) VALUES ('admin', ?)");
    $stmt->execute([$newHash]);
    echo "<p style='color:green;font-size:18px;'>✅ Admin user created successfully!</p>";
}

// Verify it works
$stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = 'admin'");
$stmt->execute();
$user = $stmt->fetch();

echo "<p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>";
echo "<p><strong>Hash stored:</strong> " . htmlspecialchars($user['password_hash']) . "</p>";
echo "<p><strong>Verify test (admin123):</strong> " . (password_verify('admin123', $user['password_hash']) ? '<span style="color:green">PASS ✅</span>' : '<span style="color:red">FAIL ❌</span>') . "</p>";
echo "<br><a href='login.php' style='background:#1e3a8a;color:white;padding:10px 20px;border-radius:5px;text-decoration:none;'>Go to Login →</a>";
?>
