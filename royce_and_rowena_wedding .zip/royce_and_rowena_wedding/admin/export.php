<?php
// Clear any previous output buffers to ensure clean headers
if (ob_get_level()) ob_end_clean();

require_once 'auth.php';
require_once '../includes/db.php';

// Fetch the data first so we know it's ready
$stmt = $pdo->query("SELECT full_name, attendance, contact_number, message, submitted_at FROM rsvps ORDER BY submitted_at DESC");
$rsvps = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set headers for true Excel download
$filename = "Wedding_Guest_List.xls";
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// Start the table for Excel compatibility
echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
echo '<head><meta http-equiv="Content-type" content="text/html;charset=utf-8" /></head>';
echo '<body>';
echo '<table border="1">';
echo '<tr>
        <th style="background-color: #002349; color: white;">Full Name</th>
        <th style="background-color: #002349; color: white;">Attending?</th>
        <th style="background-color: #002349; color: white;">Contact Number</th>
        <th style="background-color: #002349; color: white;">Message</th>
        <th style="background-color: #002349; color: white;">Date Submitted</th>
      </tr>';

foreach ($rsvps as $row) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($row['full_name']) . '</td>';
    echo '<td>' . htmlspecialchars($row['attendance']) . '</td>';
    echo '<td>' . htmlspecialchars($row['contact_number']) . '</td>';
    echo '<td>' . htmlspecialchars($row['message']) . '</td>';
    echo '<td>' . date('M j, Y g:i A', strtotime($row['submitted_at'])) . '</td>';
    echo '</tr>';
}

echo '</table>';
echo '</body>';
echo '</html>';
exit;
?>
