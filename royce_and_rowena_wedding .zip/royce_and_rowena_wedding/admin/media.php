<?php
require_once 'auth.php';
require_once '../includes/db.php';

// Fetch slideshow images
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'slideshow' ORDER BY sort_order ASC");
$stmt->execute();
$slideshow_images = $stmt->fetchAll();

// Fetch gallery images
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'gallery' ORDER BY sort_order ASC");
$stmt->execute();
$gallery_images = $stmt->fetchAll();

// Fetch attire images
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'attire' ORDER BY sort_order ASC");
$stmt->execute();
$attire_images = $stmt->fetchAll();

// Fetch venue images
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'venue' ORDER BY sort_order ASC");
$stmt->execute();
$venue_images = $stmt->fetchAll();

// Fetch pre-wedding videos
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'pre_wedding_video' ORDER BY sort_order ASC");
$stmt->execute();
$pre_wedding_videos = $stmt->fetchAll();

// Fetch venue main images
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'venue_main' ORDER BY sort_order ASC");
$stmt->execute();
$venue_main_images = $stmt->fetchAll();

// Fetch QR Code images
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'qr_code' ORDER BY sort_order ASC");
$stmt->execute();
$qr_code_images = $stmt->fetchAll();

// Fetch other details images
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'other_details' ORDER BY sort_order ASC");
$stmt->execute();
$other_details_images = $stmt->fetchAll();

// Fetch RSVP background videos
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'rsvp_bg_video' ORDER BY sort_order ASC");
$stmt->execute();
$rsvp_bg_videos = $stmt->fetchAll();

// Fetch background music
$stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'background_music' ORDER BY sort_order ASC");
$stmt->execute();
$background_music = $stmt->fetchAll();


function get_max_upload_size_bytes() {
    $val = trim(ini_get('upload_max_filesize'));
    $last = strtolower($val[strlen($val)-1]);
    $val = (int)$val;
    switch($last) {
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }
    return $val;
}
function get_max_post_size_bytes() {
    $val = trim(ini_get('post_max_size'));
    $last = strtolower($val[strlen($val)-1]);
    $val = (int)$val;
    switch($last) {
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }
    return $val;
}
$max_upload_bytes = get_max_upload_size_bytes();
$max_post_bytes = get_max_post_size_bytes();
$limit_bytes = min($max_upload_bytes, $max_post_bytes);
$limit_formatted = ini_get('upload_max_filesize');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Manager - <?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-blue-900 p-4 text-white flex justify-between items-center">
        <div class="flex items-center gap-4">
            <a href="index.php" class="hover:text-blue-200 transition-colors">
                <span class="material-symbols-outlined align-middle">arrow_back</span>
            </a>
            <h1 class="text-xl font-bold">Media Manager</h1>
        </div>
        <div class="flex items-center gap-8">
            <a href="index.php" class="text-sm hover:underline">Dashboard</a>
            <a href="faqs.php" class="text-sm hover:underline">FAQs Manager</a>
            <a href="settings.php" class="text-sm hover:underline">Website Settings</a>
            <a href="change_password.php" class="text-sm hover:underline">Change Password</a>
            <a href="logout.php" class="text-sm hover:underline">Logout</a>
        </div>
    </nav>

    <div class="container mx-auto p-8">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?= $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?= $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <!-- Upload Form -->
        <div class="bg-white p-6 rounded shadow mb-8 relative">
            <!-- Loading Overlay -->
            <div id="loadingOverlay" class="hidden absolute inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center rounded">
                <div class="animate-spin rounded-full h-12 w-12 border-4 border-blue-200 border-b-blue-900 mb-3"></div>
                <p class="text-blue-900 font-semibold">Uploading...</p>
            </div>

            <h2 class="text-xl font-bold mb-4">Upload New Media</h2>
            <form action="upload_media.php" method="POST" enctype="multipart/form-data" class="grid md:grid-cols-4 gap-4 items-end" onsubmit="document.getElementById('loadingOverlay').classList.remove('hidden');">
                <div class="space-y-1">
                    <label class="block text-sm font-bold text-gray-700">Select File <span class="text-xs font-normal text-gray-500">(Max: <?= $limit_formatted ?>)</span></label>
                    <input type="file" name="image" accept="image/*,video/*" required class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                </div>
                <div class="space-y-1">
                    <label class="block text-sm font-bold text-gray-700">Category</label>
                    <select name="category" id="categorySelect" class="w-full border rounded p-2">
                        <option value="slideshow">Hero Slideshow</option>
                        <option value="gallery">Engagement Gallery</option>
                        <option value="attire">Attire Guide</option>
                        <option value="venue">Venue / Church</option>
                        <option value="venue_main">Venue Main (Slideshow)</option>
                        <option value="pre_wedding_video">Pre Wedding Video (Video)</option>
                        <option value="rsvp_bg_video">RSVP Background Video (Video)</option>
                        <option value="background_music">Background Music (Audio)</option>
                        <option value="qr_code">Banking QR Code</option>
                        <option value="other_details">Other Details (Invitation)</option>
                    </select>
                </div>
                <div class="space-y-1">
                    <label class="block text-sm font-bold text-gray-700">Alt Text (Optional)</label>
                    <input type="text" name="alt_text" placeholder="e.g. Couple laughing" class="w-full border rounded p-2">
                </div>
                <button type="submit" id="uploadButton" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-200">
                    Upload Image
                </button>
            </form>
        </div>

        <?php 
        $sections = [
            ['title' => 'Hero Slideshow', 'icon' => 'slideshow', 'data' => $slideshow_images],
            ['title' => 'Engagement Gallery', 'icon' => 'gallery_thumbnail', 'data' => $gallery_images],
            ['title' => 'Attire Guide', 'icon' => 'checkroom', 'data' => $attire_images],
            ['title' => 'Venue / Church', 'icon' => 'location_on', 'data' => $venue_images],
            ['title' => 'Venue Main (Slideshow)', 'icon' => 'landscape', 'data' => $venue_main_images],
            ['title' => 'Pre Wedding Video', 'icon' => 'videocam', 'data' => $pre_wedding_videos],
            ['title' => 'RSVP Background Video', 'icon' => 'video_library', 'data' => $rsvp_bg_videos],
            ['title' => 'Background Music', 'icon' => 'music_note', 'data' => $background_music],
            ['title' => 'Banking QR Code', 'icon' => 'qr_code', 'data' => $qr_code_images],
            ['title' => 'Other Details (Invitation)', 'icon' => 'info', 'data' => $other_details_images],
        ];

        foreach ($sections as $section):
        ?>
        <div class="mb-12">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <span class="material-symbols-outlined"><?= $section['icon'] ?></span>
                <?= $section['title'] ?>
            </h2>
            <?php if (empty($section['data'])): ?>
                <p class="text-gray-500 italic bg-white p-4 rounded shadow">No media in this category yet.</p>
            <?php else: ?>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    <?php foreach ($section['data'] as $img): ?>
                        <div class="bg-white rounded-lg shadow-md overflow-hidden relative group">
                            <?php if ($section['icon'] === 'videocam' || $section['icon'] === 'video_library'): ?>
                                <video src="<?= BASE_URL ?>/<?= htmlspecialchars($img['file_path']) ?>#t=0.001" class="w-full h-48 object-cover animate-fade-in" preload="metadata" playsinline controls></video>
                            <?php elseif ($section['icon'] === 'music_note'): ?>
                                <div class="w-full h-48 bg-slate-100 flex flex-col items-center justify-center p-4">
                                    <span class="material-symbols-outlined text-5xl text-blue-900 mb-2">music_note</span>
                                    <audio src="<?= BASE_URL ?>/<?= htmlspecialchars($img['file_path']) ?>" class="w-full" preload="metadata" controls></audio>
                                </div>
                            <?php else: ?>
                                <img src="<?= BASE_URL ?>/<?= htmlspecialchars($img['file_path']) ?>" alt="<?= htmlspecialchars($img['alt_text']) ?>" class="w-full h-48 object-cover">
                            <?php endif; ?>
                            <div class="p-3 flex justify-between items-center bg-gray-50 border-t">
                                <span class="text-xs font-bold text-gray-500 uppercase tracking-tighter">Order: <?= $img['sort_order'] ?></span>
                                <a href="delete_media.php?id=<?= $img['id'] ?>" 
                                   class="relative z-50 bg-red-100 hover:bg-red-600 text-red-600 hover:text-white p-3 rounded-lg transition-all duration-200 flex items-center justify-center shadow-sm"
                                   title="Delete Image">
                                    <span class="material-symbols-outlined !text-2xl">delete</span>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const categorySelect = document.getElementById('categorySelect');
        const uploadButton = document.getElementById('uploadButton');
        const fileInput = document.querySelector('input[type="file"]');
        const form = document.querySelector('form');
        const limitBytes = <?= $limit_bytes ?>;
        const limitFormatted = "<?= $limit_formatted ?>";

        function updateFormState() {
            const isVideo = categorySelect.value === 'pre_wedding_video' || categorySelect.value === 'rsvp_bg_video';
            const isAudio = categorySelect.value === 'background_music';
            if (isVideo) {
                fileInput.setAttribute('accept', 'video/*');
                uploadButton.textContent = 'Upload Video';
            } else if (isAudio) {
                fileInput.setAttribute('accept', 'audio/*');
                uploadButton.textContent = 'Upload Audio';
            } else {
                fileInput.setAttribute('accept', 'image/*');
                uploadButton.textContent = 'Upload Image';
            }
        }

        categorySelect.addEventListener('change', updateFormState);
        updateFormState(); // Initial run

        form.addEventListener('submit', function(e) {
            if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                if (file.size > limitBytes) {
                    e.preventDefault();
                    document.getElementById('loadingOverlay').classList.add('hidden');
                    alert('Error: The selected file is too large (' + (file.size / (1024 * 1024)).toFixed(2) + ' MB). The maximum allowed size by the server is ' + limitFormatted + '. Please choose a smaller file or compress it.');
                    return false;
                }
            }
        });
    });
    </script>
</body>
</html>
