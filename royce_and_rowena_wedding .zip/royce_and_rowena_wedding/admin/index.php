<?php
require_once 'auth.php';
require_once '../includes/db.php';

// Fetch all RSVPs
$stmt = $pdo->query("SELECT * FROM rsvps ORDER BY submitted_at DESC");
$rsvps = $stmt->fetchAll();

// Calculate stats
$total_attending = 0;
$total_declined = 0;
foreach ($rsvps as $rsvp) {
    if ($rsvp['attendance'] === 'Yes') {
        $total_attending++;
    } else {
        $total_declined++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>">
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-blue-900 p-4 text-white flex justify-between items-center">
        <div class="flex items-center gap-4">
            <img src="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>" alt="Logo" class="h-10 w-10 object-cover rounded-full ring-2 ring-white/30">
            <h1 class="text-xl font-bold">Admin Dashboard</h1>
        </div>
        <div class="flex items-center gap-6">
            <a href="media.php" class="bg-blue-700 hover:bg-blue-800 text-white text-sm font-bold py-1 px-3.5 rounded transition duration-200 flex items-center gap-1.5 shadow-sm">
                <span class="material-symbols-outlined text-sm">imagesmode</span>
                Media Manager
            </a>
            <a href="faqs.php" class="bg-blue-700 hover:bg-blue-800 text-white text-sm font-bold py-1 px-3.5 rounded transition duration-200 flex items-center gap-1.5 shadow-sm">
                <span class="material-symbols-outlined text-sm">quiz</span>
                FAQs Manager
            </a>
            <a href="settings.php" class="bg-blue-700 hover:bg-blue-800 text-white text-sm font-bold py-1 px-3.5 rounded transition duration-200 flex items-center gap-1.5 shadow-sm">
                <span class="material-symbols-outlined text-sm">settings</span>
                Settings
            </a>
            <a href="change_password.php" class="text-sm hover:underline">Change Password</a>
            <a href="logout.php" class="text-sm hover:underline">Logout (<?= htmlspecialchars($_SESSION['admin_username']) ?>)</a>
        </div>
    </nav>
    <div class="container mx-auto p-8">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm flex items-center gap-3">
                <span class="material-symbols-outlined">check_circle</span>
                <p><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded shadow-sm flex items-center gap-3">
                <span class="material-symbols-outlined">error</span>
                <p><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-2 gap-4 mb-8">
            <div class="bg-white p-6 rounded shadow text-center">
                <h2 class="text-gray-500 font-bold uppercase text-sm mb-1">Attending</h2>
                <p class="text-4xl font-bold text-green-600"><?= $total_attending ?></p>
            </div>
            <div class="bg-white p-6 rounded shadow text-center">
                <h2 class="text-gray-500 font-bold uppercase text-sm mb-1">Declined</h2>
                <p class="text-4xl font-bold text-red-600"><?= $total_declined ?></p>
            </div>
        </div>

        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-gray-800">RSVP List</h3>
            <a href="export.php" class="relative z-50 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg inline-flex items-center transition duration-200 shadow-md">
                <span class="material-symbols-outlined mr-2">description</span>
                Export to Excel (.xls)
            </a>
        </div>
        <div class="bg-white rounded shadow overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600">Name</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600">Attending?</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600">Contact</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600">Message</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600">Date</th>
                        <th class="py-3 px-4 uppercase font-bold text-sm text-gray-600 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rsvps as $rsvp): ?>
                    <tr class="border-t hover:bg-gray-50">
                        <td class="py-3 px-4 font-bold text-blue-900"><?= htmlspecialchars($rsvp['full_name']) ?></td>
                        <td class="py-3 px-4">
                            <span class="<?= $rsvp['attendance'] === 'Yes' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?> px-3 py-1 rounded-full text-xs font-bold uppercase">
                                <?= htmlspecialchars($rsvp['attendance']) ?>
                            </span>
                        </td>
                        <td class="py-3 px-4 text-sm font-mono"><?= htmlspecialchars($rsvp['contact_number'] ?? '-') ?></td>
                        <td class="py-3 px-4 text-sm max-w-xs truncate" title="<?= htmlspecialchars($rsvp['message'] ?? '') ?>"><?= htmlspecialchars($rsvp['message'] ?? '-') ?></td>
                        <td class="py-3 px-4 text-sm text-gray-500 whitespace-nowrap"><?= date('M j, Y g:i A', strtotime($rsvp['submitted_at'])) ?></td>
                        <td class="py-3 px-4 text-right whitespace-nowrap">
                            <a href="edit_rsvp.php?id=<?= $rsvp['id'] ?>" class="text-blue-600 hover:text-blue-900 transition-colors duration-200 mr-3" title="Edit RSVP">
                                <span class="material-symbols-outlined text-xl">edit</span>
                            </a>
                            <a href="delete_rsvp.php?id=<?= $rsvp['id'] ?>" 
                               class="text-red-500 hover:text-red-700 transition-colors duration-200" 
                               title="Delete RSVP"
                               onclick="return confirm('Are you sure you want to delete this RSVP? This action cannot be undone.');">
                                <span class="material-symbols-outlined text-xl">delete</span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if (empty($rsvps)): ?>
                <p class="p-4 text-center text-gray-500 italic">No RSVPs received yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
