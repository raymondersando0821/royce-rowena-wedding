<?php
// includes/db.php
require_once 'config.php';

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (\PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Load all site settings dynamically
$db_settings = [];
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM site_settings");
    while ($row = $stmt->fetch()) {
        $db_settings[$row['setting_key']] = $row['setting_value'];
    }
    
    // Auto-seed video_youtube_link if missing
    if (!array_key_exists('video_youtube_link', $db_settings)) {
        $stmt_seed = $pdo->prepare("INSERT IGNORE INTO site_settings (setting_key, setting_value, setting_label, setting_section, setting_type) VALUES ('video_youtube_link', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'Pre-Wedding Video YouTube Link', 'Story & Video', 'text')");
        $stmt_seed->execute();
        $db_settings['video_youtube_link'] = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
    }
} catch (\PDOException $e) {
    // If settings table doesn't exist yet, catch silently
}

// Define site constants using settings or fallback to defaults
if (!defined('SITE_TITLE')) {
    define('SITE_TITLE', $db_settings['site_title'] ?? 'Royce & Rowena Wedding');
}
if (!defined('WEDDING_DATE')) {
    define('WEDDING_DATE', $db_settings['wedding_date'] ?? 'August 21, 2026');
}

// Helper function to get text settings
if (!function_exists('get_setting')) {
    function get_setting($key, $default = '') {
        global $db_settings;
        return isset($db_settings[$key]) ? $db_settings[$key] : $default;
    }
}

// Helper function to extract YouTube video ID from standard or short URLs
if (!function_exists('get_youtube_id')) {
    function get_youtube_id($url) {
        $video_id = null;
        if (preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/\s]{11})%i', $url, $match)) {
            $video_id = $match[1];
        }
        return $video_id;
    }
}
?>
