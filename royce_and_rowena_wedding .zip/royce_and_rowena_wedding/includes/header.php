<?php 
require_once 'db.php'; 

// Fetch background music
$bg_music_stmt = $pdo->prepare("SELECT * FROM media WHERE category = 'background_music' LIMIT 1");
$bg_music_stmt->execute();
$bg_music_file = $bg_music_stmt->fetch();
?>
<!DOCTYPE html>
<html class="scroll-smooth" lang="en">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title><?= SITE_TITLE ?></title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600&amp;family=Noto+Serif:ital,wght@0,400;1,400&amp;display=swap" rel="stylesheet"/>
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <script id="tailwind-config">
      tailwind.config = {
        darkMode: "class",
        theme: {
          extend: {
            "colors": {
                    "secondary-container": "#fed488",
                    "on-tertiary-fixed-variant": "#474744",
                    "surface-container-high": "#eae7e7",
                    "surface-variant": "#e5e2e1",
                    "on-surface": "#1c1b1b",
                    "primary": "#000d22",
                    "on-error-container": "#93000a",
                    "surface-container-low": "#f6f3f2",
                    "on-surface-variant": "#43474e",
                    "tertiary-fixed": "#e4e2dd",
                    "inverse-primary": "#adc8f6",
                    "tertiary-fixed-dim": "#c8c6c2",
                    "primary-fixed": "#d5e3ff",
                    "primary-fixed-dim": "#adc8f6",
                    "on-tertiary": "#ffffff",
                    "surface-bright": "#fcf9f8",
                    "on-primary": "#ffffff",
                    "tertiary": "#0c0d0b",
                    "on-tertiary-fixed": "#1b1c19",
                    "on-secondary-fixed": "#261900",
                    "error": "#ba1a1a",
                    "on-tertiary-container": "#8b8a86",
                    "surface-container-lowest": "#ffffff",
                    "surface-container-highest": "#e5e2e1",
                    "inverse-surface": "#313030",
                    "error-container": "#ffdad6",
                    "on-secondary-fixed-variant": "#5d4201",
                    "secondary": "#775a19",
                    "surface-tint": "#455f88",
                    "outline": "#74777f",
                    "on-primary-fixed": "#001b3c",
                    "surface-container": "#f0eded",
                    "primary-container": "#002349",
                    "inverse-on-surface": "#f3f0ef",
                    "on-background": "#1c1b1b",
                    "on-secondary-container": "#785a1a",
                    "outline-variant": "#c4c6cf",
                    "surface": "#fcf9f8",
                    "background": "#fcf9f8",
                    "on-primary-fixed-variant": "#2c476f",
                    "tertiary-container": "#222320",
                    "secondary-fixed": "#ffdea5",
                    "secondary-fixed-dim": "#e9c176",
                    "on-primary-container": "#718bb7",
                    "on-secondary": "#ffffff",
                    "surface-dim": "#dcd9d9",
                    "on-error": "#ffffff"
            },
            "borderRadius": {
                    "DEFAULT": "0.25rem",
                    "lg": "0.5rem",
                    "xl": "0.75rem",
                    "full": "9999px"
            },
            "spacing": {
                    "stack-lg": "64px",
                    "unit": "8px",
                    "gutter": "24px",
                    "section-padding": "120px",
                    "container-max": "1140px",
                    "stack-sm": "16px",
                    "stack-md": "32px"
            },
            "fontFamily": {
                    "body-md": ["Manrope"],
                    "display-lg": ["Noto Serif"],
                    "body-lg": ["Manrope"],
                    "label-caps": ["Manrope"],
                    "headline-md": ["Noto Serif"],
                    "headline-lg": ["Noto Serif"]
            },
            "fontSize": {
                    "body-md": ["16px", {"lineHeight": "1.6", "letterSpacing": "0.01em", "fontWeight": "400"}],
                    "display-lg": ["64px", {"lineHeight": "1.1", "letterSpacing": "-0.02em", "fontWeight": "400"}],
                    "body-lg": ["18px", {"lineHeight": "1.6", "letterSpacing": "0.01em", "fontWeight": "400"}],
                    "label-caps": ["12px", {"lineHeight": "1.0", "letterSpacing": "0.2em", "fontWeight": "600"}],
                    "headline-md": ["32px", {"lineHeight": "1.3", "letterSpacing": "0em", "fontWeight": "400"}],
                    "headline-lg": ["40px", {"lineHeight": "1.2", "letterSpacing": "0em", "fontWeight": "400"}]
            }
          },
        },
      }
    </script>
    <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet"/>
</head>
<body class="bg-background text-on-background font-body-md <?= $bg_music_file ? 'overflow-hidden' : '' ?>">
<?php if ($bg_music_file): ?>
    <!-- Welcome Overlay Screen -->
    <div id="welcome-overlay" class="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#fcfaf7] dark:bg-slate-950 text-center px-6 transition-all duration-700">
        <div class="max-w-md space-y-8 flex flex-col items-center opacity-0">
            <!-- Logo or Icon -->
            <div class="mb-2 welcome-animate">
                <img src="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>" alt="<?= SITE_TITLE ?>" class="h-24 w-24 mx-auto object-cover rounded-full ring-4 ring-amber-200 shadow-lg">
            </div>
            
            <div class="space-y-3">
                <span class="font-serif text-xs uppercase tracking-[0.3em] text-amber-700 dark:text-amber-500 block welcome-animate">You are invited to the wedding of</span>
                <h1 class="font-display-lg text-4xl md:text-5xl italic leading-tight text-[#002349] dark:text-slate-100 font-serif my-4 welcome-animate"><?= SITE_TITLE ?></h1>
                <div class="w-16 h-[1px] bg-amber-200/50 mx-auto welcome-animate"></div>
                <p class="font-serif tracking-widest uppercase text-sm text-slate-500 dark:text-slate-400 mt-3 welcome-animate"><?= WEDDING_DATE ?></p>
            </div>

            <button id="open-invitation-btn" style="background-color: #002349 !important; color: #ffffff !important; display: inline-block !important; opacity: 1 !important; visibility: visible !important;" class="mt-8 px-10 py-4 bg-primary-container hover:bg-primary text-white font-serif tracking-[0.2em] uppercase text-xs rounded-none shadow-xl hover:shadow-2xl active:scale-95 transition-all duration-300 border border-amber-200/30 relative overflow-hidden group welcome-animate">
                <span class="absolute inset-0 w-full h-full bg-gradient-to-r from-amber-600/20 to-transparent transform -skew-x-12 -translate-x-full group-hover:animate-shimmer"></span>
                Open Invitation
            </button>
        </div>
    </div>
<?php endif; ?>
<!-- TopAppBar Component -->
<header class="sticky top-0 w-full z-50 bg-[#fcfaf7] dark:bg-slate-950 border-b border-amber-200/40 dark:border-slate-800 transition-colors duration-500">
    <nav class="flex justify-between items-center px-8 md:px-16 py-6 w-full">
        <div class="flex items-center">
            <a href="<?= BASE_URL ?>" class="flex items-center gap-3">
                <img src="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>" alt="<?= SITE_TITLE ?>" class="h-12 w-12 object-cover rounded-full ring-2 ring-amber-200">
                <span class="font-serif italic text-2xl tracking-tighter text-[#002349] dark:text-slate-100 hidden sm:block"><?= SITE_TITLE ?></span>
            </a>
        </div>
        <div class="hidden md:flex items-center space-x-8">
            <a class="font-serif tracking-wide uppercase text-sm text-amber-700 dark:text-amber-500 border-b border-amber-700 pb-1 hover:text-amber-600 transition-colors duration-500" href="<?= BASE_URL ?>/#story">Our Story</a>
            <a class="font-serif tracking-wide uppercase text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 transition-colors duration-500" href="<?= BASE_URL ?>/#venue">Venue</a>
            <a class="font-serif tracking-wide uppercase text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 transition-colors duration-500" href="<?= BASE_URL ?>/#rsvp">RSVP</a>
            <a class="font-serif tracking-wide uppercase text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 transition-colors duration-500" href="<?= BASE_URL ?>/#gallery">Gallery</a>
            <a class="font-serif tracking-wide uppercase text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 transition-colors duration-500" href="<?= BASE_URL ?>/#attire">Attire</a>
            <a class="font-serif tracking-wide uppercase text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 transition-colors duration-500" href="<?= BASE_URL ?>/#registry">Gift</a>
            <a class="font-serif tracking-wide uppercase text-sm text-slate-500 dark:text-slate-400 hover:text-amber-600 transition-colors duration-500" href="<?= BASE_URL ?>/#faq">FAQ</a>
        </div>
        <div class="flex items-center">
            <a class="bg-primary-container text-white px-6 py-2 font-serif tracking-wide uppercase text-xs hover:bg-primary transition-all duration-300" href="<?= BASE_URL ?>/#rsvp">
                RSVP Now
            </a>
            <button id="mobile-menu-toggle" class="md:hidden text-primary dark:text-slate-100 focus:outline-none ml-3 flex items-center justify-center p-1 rounded-lg hover:bg-amber-100/50 active:bg-amber-100 transition-colors" aria-label="Toggle Menu">
                <span class="material-symbols-outlined text-3xl">menu</span>
            </button>
        </div>
    </nav>
    
    <!-- Mobile Navigation Drawer -->
    <div id="mobile-drawer" class="fixed inset-y-0 right-0 z-50 w-full max-w-[300px] bg-[#fcfaf7] dark:bg-slate-950 shadow-2xl border-l border-amber-200/40 dark:border-slate-800 transform translate-x-full transition-transform duration-300 ease-in-out md:hidden flex flex-col">
        <!-- Drawer Header -->
        <div class="flex justify-between items-center px-6 py-6 border-b border-amber-200/40 dark:border-slate-800">
            <div class="flex items-center gap-2">
                <img src="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>" alt="Logo" class="h-9 w-9 object-cover rounded-full ring-2 ring-amber-200">
                <span class="font-serif italic text-lg tracking-tighter text-[#002349] dark:text-slate-100"><?= SITE_TITLE ?></span>
            </div>
            <button id="mobile-menu-close" class="text-primary dark:text-slate-100 focus:outline-none p-1 rounded-lg hover:bg-amber-100/50 transition-colors" aria-label="Close Menu">
                <span class="material-symbols-outlined text-2xl">close</span>
            </button>
        </div>
        
        <!-- Drawer Links -->
        <div class="flex flex-col items-center justify-center space-y-6 flex-grow py-8 overflow-y-auto">
            <a class="mobile-nav-link font-serif tracking-widest uppercase text-sm text-[#002349] dark:text-slate-200 hover:text-amber-700 transition-colors" href="<?= BASE_URL ?>/#story">Our Story</a>
            <a class="mobile-nav-link font-serif tracking-widest uppercase text-sm text-[#002349] dark:text-slate-200 hover:text-amber-700 transition-colors" href="<?= BASE_URL ?>/#venue">Venue</a>
            <a class="mobile-nav-link font-serif tracking-widest uppercase text-sm text-[#002349] dark:text-slate-200 hover:text-amber-700 transition-colors" href="<?= BASE_URL ?>/#rsvp">RSVP</a>
            <a class="mobile-nav-link font-serif tracking-widest uppercase text-sm text-[#002349] dark:text-slate-200 hover:text-amber-700 transition-colors" href="<?= BASE_URL ?>/#gallery">Gallery</a>
            <a class="mobile-nav-link font-serif tracking-widest uppercase text-sm text-[#002349] dark:text-slate-200 hover:text-amber-700 transition-colors" href="<?= BASE_URL ?>/#attire">Attire</a>
            <a class="mobile-nav-link font-serif tracking-widest uppercase text-sm text-[#002349] dark:text-slate-200 hover:text-amber-700 transition-colors" href="<?= BASE_URL ?>/#registry">Gift</a>
            <a class="mobile-nav-link font-serif tracking-widest uppercase text-sm text-[#002349] dark:text-slate-200 hover:text-amber-700 transition-colors" href="<?= BASE_URL ?>/#faq">FAQ</a>
        </div>

        <!-- RSVP Button in Drawer -->
        <div class="p-6 border-t border-amber-200/40 dark:border-slate-800 text-center">
            <a class="mobile-nav-link block bg-primary-container text-white py-3 font-serif tracking-widest uppercase text-xs hover:bg-primary transition-all duration-300" href="<?= BASE_URL ?>/#rsvp">
                RSVP Now
            </a>
        </div>
    </div>
</header>
<?php if ($bg_music_file): ?>
    <!-- Background Music Audio Tag -->
    <audio id="bg-music" loop preload="auto">
        <source src="<?= BASE_URL ?>/<?= htmlspecialchars($bg_music_file['file_path']) ?>" type="audio/<?= pathinfo($bg_music_file['file_path'], PATHINFO_EXTENSION) ?>">
    </audio>

    <!-- Floating Audio Control Button -->
    <div class="fixed bottom-6 right-6 z-[99] flex items-center justify-center">
        <button id="bg-music-toggle" class="bg-primary/95 text-white w-14 h-14 rounded-full shadow-2xl flex items-center justify-center border border-amber-200/30 hover:bg-secondary/95 hover:scale-105 active:scale-95 transition-all duration-300 group relative" aria-label="Toggle background music">
            <!-- Ripple/pulse effect when playing -->
            <span class="absolute inset-0 rounded-full bg-amber-500/25 animate-ping hidden" id="music-pulse"></span>
            <!-- Icon -->
            <span class="material-symbols-outlined text-2xl relative z-10" id="music-icon">volume_up</span>
        </button>
    </div>
<?php endif; ?>
<main>
