</main>
<!-- Footer Component -->
<footer class="bg-[#fcfaf7] dark:bg-slate-950 border-t border-amber-200/40 dark:border-slate-800 py-12">
    <div class="flex flex-col items-center justify-center space-y-6 w-full text-center">
        <div class="flex space-x-8">
            <a class="font-serif text-xs uppercase tracking-[0.2em] text-slate-400 hover:text-amber-600 transition-colors" href="#">Privacy Policy</a>
            <a class="font-serif text-xs uppercase tracking-[0.2em] text-slate-400 hover:text-amber-600 transition-colors" href="#">Contact Us</a>
        </div>
        <div class="mb-4">
            <img src="<?= BASE_URL ?>/assets/images/logo.png?v=<?= filemtime(__DIR__ . '/../assets/images/logo.png') ?>" alt="<?= SITE_TITLE ?>" class="h-16 w-16 mx-auto object-cover rounded-full ring-2 ring-amber-200">
        </div>
        <p class="font-serif text-xs uppercase tracking-[0.2em] text-[#002349] dark:text-slate-100">
            © <?= date('Y') ?> <?= SITE_TITLE ?>. Handcrafted with love.
        </p>
    </div>
</footer>
<script>window.BASE_URL = '<?= BASE_URL ?>';</script>
<script src="<?= BASE_URL ?>/assets/js/main.js?v=<?= filemtime(__DIR__ . '/../assets/js/main.js') ?>"></script>
</body>
</html>
