<?php
// includes/config.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'royce_and_rowena_wedding');

// ─── Auto-detect Base URL ────────────────────────────────────────────────────
// Works on XAMPP localhost, shared hosting at root, and hosting in a
// subdirectory — no manual changes needed when deploying.
if (!defined('BASE_URL')) {
    $protocol   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host       = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $docRoot    = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? getcwd()));
    $projectDir = str_replace('\\', '/', realpath(__DIR__ . '/..'));
    $subPath    = rtrim(str_replace($docRoot, '', $projectDir), '/');
    define('BASE_URL', $protocol . '://' . $host . $subPath);
}
// ────────────────────────────────────────────────────────────────────────────

// Site Information will be loaded dynamically in db.php

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
